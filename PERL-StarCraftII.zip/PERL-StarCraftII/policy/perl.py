import torch
import os
from network.base_net import RNN
from network.perl_net import PERLNet
import math
import random
import numpy as np
from torch.autograd import Variable
import tensorflow as tf
tf.compat.v1.disable_eager_execution()  # 降级tensorflow 使得tensorflow 2.0版本可以使用1.0版本函数


class PERL:
    def __init__(self, args):
        self.n_actions = args.n_actions
        self.n_agents = args.n_agents
        self.state_shape = args.state_shape
        self.obs_shape = args.obs_shape
        self.epoch=args.n_epoch
        input_shape = self.obs_shape
        # 根据参数决定RNN的输入维度
        # whether to use the last action to choose action
        # args.last_action=False
        if args.last_action:
            input_shape += self.n_actions
        # whether to use one network for all agents
        if args.reuse_network:
            input_shape += self.n_agents

        # 神经网络

        self.eval_rnn = RNN(input_shape, args) # 每个agent选动作的网络,当作q.learner看待
        self.target_rnn = RNN(input_shape, args)  # q.target
        self.eval_perl_net = PERLNet(args)  # 把agents Q值加起来的网络
        self.target_perl_net = PERLNet(args)
        self.args = args
        # 是否使用GPU,在common.arguments里修改--cuda的值,默认不适用，修改为True使用
        if self.args.cuda:
            self.eval_rnn.cuda()
            self.target_rnn.cuda()
            self.eval_perl_net.cuda()
            self.target_perl_net.cuda()
        self.model_dir = args.model_dir + '/' + args.alg + '/' + args.map
        # 如果存在模型则加载模型
        if self.args.load_model:
            if os.path.exists(self.model_dir + '/rnn_net_params.pkl'):
                path_rnn = self.model_dir + '/rnn_net_params.pkl'
                path_perl = self.model_dir + '/perl_net_params.pkl'
                self.eval_rnn.load_state_dict(torch.load(path_rnn))
                self.eval_perl_net.load_state_dict(torch.load(path_perl))
                print('Successfully load the model: {} and {}'.format(path_rnn, path_perl))
            else:
                raise Exception("No model!")

        # 让target_net和eval_net的网络参数相同
        self.target_rnn.load_state_dict(self.eval_rnn.state_dict())
        self.target_perl_net.load_state_dict(self.eval_perl_net.state_dict())

        self.eval_parameters = list(self.eval_perl_net.parameters()) + list(self.eval_rnn.parameters())
        if args.optimizer == "RMS":
            self.optimizer = torch.optim.RMSprop(self.eval_parameters, lr=args.lr)

        # 执行过程中，要为每个agent都维护一个eval_hidden
        # 学习过程中，要为每个episode的每个agent都维护一个eval_hidden、target_hidden
        self.eval_hidden = None
        self.target_hidden = None
        print('Init alg PERL')

    # 拼接状态-动作,传入数据是字典
    # 状态、动作等数据均存放在自己的字典
    def sc_data(self,data):
        '''
        :param data: dict
        :return: list
        '''
        scl=[]
        for j in range(len(data['s'])):
            S = data['s'][j]  # episode_len*state_shape
            A = data['u'][j]  # episode_len*n_agents*1
            for k in range(S.shape[0]):
                s=S[k].tolist()    # 1*state_shape ndarray --> list
                a=[]
                for n in range(len(A[k])): # n_agents*1 ndarray [[5],[2],[3]]
                    a.append(A[k][n][0])
                #s+=a   # 1X(state_shape+n_agents) list
                scl.append(s+a)
        return scl

    '''the version of tensorflow '''
    def get_p(self,epoch,data=None):
        '''
        :param train_steps:
        :param N:
        :param data: list
        :return: p:(i,self.state_shape+self.n_agents)
        '''
        N = self.args.N
        if math.ceil(epoch / N) < self.args.state_shape:
            i = math.ceil(epoch / N)+1
        else:
            i = self.args.state_shape
        # rm = random.randint(0, len(data)-20)
        scm=np.mat(data).T
        tf.compat.v1.reset_default_graph()
        X = tf.compat.v1.placeholder(tf.float32, [self.args.state_shape+self.args.n_agents, None])
        # 定义变量
        P = tf.compat.v1.Variable(tf.compat.v1.random_normal([i, self.args.state_shape+self.args.n_agents]))
        A = tf.matmul(P, X)
        A1 = tf.multiply(A, A)
        rdc_sum = tf.reduce_sum(A1, 1)
        lg = tf.math.log(rdc_sum)
        lg_sum = tf.reduce_sum(lg)
        cost = tf.reduce_mean(1 - lg_sum)
        learning_rate = 0.1
        optimizer = tf.compat.v1.train.GradientDescentOptimizer(learning_rate).minimize(cost)
        training_epochs = 20
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            for epoch in range(training_epochs):
                sess.run(optimizer, feed_dict={X: scm})
            p = np.mat(sess.run(P))
        return p

    '''the version of torch'''
    def get_P(self,train_steps,data=None):
        '''
        :param train_steps:
        :param N:
        :param data: list
        :return: p:(i,self.state_shape+self.n_agents)
        '''
        N=self.args.N
        if math.ceil(train_steps / N) <= self.args.state_shape:
            i = math.ceil(train_steps / N)
        else:
            i = self.args.state_shape
        data=np.mat(data).T
        P = Variable(torch.randn(i, self.args.state_shape+self.args.n_agents), requires_grad=True)
        learning_rate = 0.01
        optimizer = torch.optim.SGD([P], lr=learning_rate,momentum=0.76)
        training_epochs = 20
        for epoch in range(training_epochs):
            rm = random.randint(0, data.shape[1] - 40)
            data1 = data[:, rm:rm + 40]
            X = torch.tensor(data1, dtype=torch.float)
            A = torch.matmul(P, X)
            A1 = torch.mul(A, A)
            rdc_sum = torch.sum(A1, 0)
            #lg = torch.log(rdc_sum)
            #lg_sum = torch.sum(lg)
            cost = torch.mean(1 - torch.sum(rdc_sum))
            optimizer.zero_grad()
            cost.backward()
            optimizer.step()
        p = np.mat(P.detach().numpy())
        return p

    def get_shared_goals_idx(self,data,p):
        scm = np.mat(data).T  # scm: self.state_shape+self.n_agents X num
        M=((p*scm).astype(np.int32)).T
        L=M.tolist()
        gl = []
        first_min = min(L, key=L.count)
        for j in L:
            if L.count(j) == L.count(first_min) and j not in gl:
                gl.append(j)
        goal = random.choice(gl)
        goal_ids=[x for x, y in list(enumerate(L)) if y == goal]

        return goal_ids

    def get_shared_goals(self,data,p,n_agents):
        scm = np.mat(data).T  # scm: self.state_shape+self.n_agents X num
        M=((p*scm).astype(np.int32)).T
        L=M.tolist()
        gl = []
        first_min = min(L, key=L.count)
        for j in L:
            if L.count(j) == L.count(first_min) and j not in gl:
                gl.append(j)
        goal = random.choice(gl)
        goal_index = L.index(goal)
        s_a=scm[:,goal_index]
        gl_s = np.array(s_a[0:self.args.state_shape])
        goal_s=gl_s.reshape([-1])
        gl_a = s_a[self.args.state_shape:self.args.state_shape+self.args.n_agents]            # data['u'][i][j] : ndarray--[[5],[5],[5]]
        goal_a=np.array(gl_a)
        return goal_s,goal_a


    def update_by_index(self,data,buffer,goal_ids):
        '''
        :param data: mini_batch
        :param goal_ids: list
        :return:
        '''
        for k in range(len(goal_ids)):
            l=goal_ids[k]//60
            r=goal_ids[k]%60
            data['r'][l][r]=19.9
            buffer['r'][l][r]=19.9

        return None


    def update_by_goal(self,data,goal_s,goal_a):
        episode_num=len(data['s'])
        episode_len=len(data['s'][0])
        for i in range(episode_num):
            for j in range(episode_len):
                if (data['s'][i][j]==goal_s).all() and (data['u'][i][j]==goal_a).all():
                    data['r'][i][j]+=10
                    data['terminated'][i][j]=1
        return None


    def learn(self, batch, max_episode_len, train_step, epsilon=None):  # train_step表示是第几次学习，用来控制更新target_net网络的参数
        '''
        在learn的时候，抽取到的数据是四维的，四个维度分别为 1——第几个episode 2——episode中第几个transition
        3——第几个agent的数据 4——具体obs维度。因为在选动作时不仅需要输入当前的inputs，还要给神经网络输入hidden_state，
        hidden_state和之前的经验相关，因此就不能随机抽取经验进行学习。所以这里一次抽取多个episode，然后一次给神经网络
        传入每个episode的同一个位置的transition
        '''
        episode_num = batch['o'].shape[0]
        self.init_hidden(episode_num)
        # 把batch里的数据转化成tensor
        for key in batch.keys():
            if key == 'u':
                batch[key] = torch.tensor(batch[key], dtype=torch.long)
            else:
                batch[key] = torch.tensor(batch[key], dtype=torch.float32)
        s, s_next, u, r, avail_u, avail_u_next, terminated = batch['s'], batch['s_next'], batch['u'], \
                                                             batch['r'],  batch['avail_u'], batch['avail_u_next'],\
                                                             batch['terminated']
        # 用来把那些填充的经验的TD-error置0，从而不让它们影响到学习
        mask = 1 - batch["padded"].float()

        # 得到每个agent对应的Q值，维度为(episode个数, max_episode_len， n_agents， n_actions)
        q_evals, q_targets = self.get_q_values(batch, max_episode_len)
        if self.args.cuda:
            s = s.cuda()
            u = u.cuda()
            r = r.cuda()
            s_next = s_next.cuda()
            terminated = terminated.cuda()
            mask = mask.cuda()
        # 取每个agent动作对应的Q值，并且把最后不需要的一维去掉，因为最后一维只有一个值了
        q_evals = torch.gather(q_evals, dim=3, index=u).squeeze(3)

        # 得到target_q
        q_targets[avail_u_next == 0.0] = - 9999999
        q_targets = q_targets.max(dim=3)[0]

        q_total_eval = self.eval_perl_net(q_evals, s)
        q_total_target = self.target_perl_net(q_targets, s_next)
        # 目标函数
        targets = r + self.args.gamma * q_total_target * (1 - terminated)

        td_error = (q_total_eval - targets.detach())
        masked_td_error = mask * td_error  # 抹掉填充的经验的td_error

        # 不能直接用mean，因为还有许多经验是没用的，所以要求和再比真实的经验数，才是真正的均值
        loss = (masked_td_error ** 2).sum() / mask.sum()
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.eval_parameters, self.args.grad_norm_clip)
        self.optimizer.step()
        # 更新目标网络
        if train_step > 0 and train_step % self.args.target_update_cycle == 0:
            self.target_rnn.load_state_dict(self.eval_rnn.state_dict())
            self.target_perl_net.load_state_dict(self.eval_perl_net.state_dict())

    def _get_inputs(self, batch, transition_idx):
        # 取出所有episode上该transition_idx的经验，u_onehot要取出所有，因为要用到上一条
        obs, obs_next, u_onehot = batch['o'][:, transition_idx], \
                                  batch['o_next'][:, transition_idx], batch['u_onehot'][:]
        episode_num = obs.shape[0]
        inputs, inputs_next = [], []
        inputs.append(obs)
        inputs_next.append(obs_next)
        # 给obs添加上一个动作、agent编号

        # 如果使用最近动作选择下一个动作，要追加动作空间维度
        if self.args.last_action:
            if transition_idx == 0:  # 如果是第一条经验，就让前一个动作为0向量
                inputs.append(torch.zeros_like(u_onehot[:, transition_idx]))
            else:
                inputs.append(u_onehot[:, transition_idx - 1])
            inputs_next.append(u_onehot[:, transition_idx])
        # 如果所用智能体使用同一个网络，要追加智能体数量的维度
        if self.args.reuse_network:
            # 因为当前的obs三维的数据，每一维分别代表(episode编号，agent编号，obs维度)，直接在dim_1上添加对应的向量
            # 即可，比如给agent_0后面加(1, 0, 0, 0, 0)，表示5个agent中的0号。而agent_0的数据正好在第0行，那么需要加的
            # agent编号恰好就是一个单位矩阵，即对角线为1，其余为0
            inputs.append(torch.eye(self.args.n_agents).unsqueeze(0).expand(episode_num, -1, -1))
            inputs_next.append(torch.eye(self.args.n_agents).unsqueeze(0).expand(episode_num, -1, -1))
        # 要把obs中的三个拼起来，并且要把episode_num个episode、self.args.n_agents个agent的数据拼成40条(40,96)的数据，
        # 因为这里所有agent共享一个神经网络，每条数据中带上了自己的编号，所以还是自己的数据
        inputs = torch.cat([x.reshape(episode_num * self.args.n_agents, -1) for x in inputs], dim=1)
        inputs_next = torch.cat([x.reshape(episode_num * self.args.n_agents, -1) for x in inputs_next], dim=1)
        return inputs, inputs_next

    def get_q_values(self, batch, max_episode_len):
        episode_num = batch['o'].shape[0]
        q_evals, q_targets = [], []
        for transition_idx in range(max_episode_len):
            inputs, inputs_next = self._get_inputs(batch, transition_idx)  # 给obs加last_action、agent_id
            if self.args.cuda:
                inputs = inputs.cuda()
                inputs_next = inputs_next.cuda()
                self.eval_hidden = self.eval_hidden.cuda()
                self.target_hidden = self.target_hidden.cuda()
            q_eval, self.eval_hidden = self.eval_rnn(inputs, self.eval_hidden)  # inputs维度为(40,96)，得到的q_eval维度为(40,n_actions)
            q_target, self.target_hidden = self.target_rnn(inputs_next, self.target_hidden)

            # 把q_eval维度重新变回(8, 5,n_actions)
            q_eval = q_eval.view(episode_num, self.n_agents, -1)
            q_target = q_target.view(episode_num, self.n_agents, -1)
            q_evals.append(q_eval)
            q_targets.append(q_target)
        # 得的q_eval和q_target是一个列表，列表里装着max_episode_len个数组，数组的的维度是(episode个数, n_agents，n_actions)
        # 把该列表转化成(episode个数, max_episode_len， n_agents，n_actions)的数组
        q_evals = torch.stack(q_evals, dim=1)
        q_targets = torch.stack(q_targets, dim=1)
        return q_evals, q_targets

    def init_hidden(self, episode_num):
        # 为每个episode中的每个agent都初始化一个eval_hidden、target_hidden
        self.eval_hidden = torch.zeros((episode_num, self.n_agents, self.args.rnn_hidden_dim))
        self.target_hidden = torch.zeros((episode_num, self.n_agents, self.args.rnn_hidden_dim))

    def save_model(self, train_step):
        num = str(train_step // self.args.save_cycle)
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)
        torch.save(self.eval_perl_net.state_dict(), self.model_dir + '/' + num + '_perl_net_params.pkl')
        torch.save(self.eval_rnn.state_dict(),  self.model_dir + '/' + num + '_rnn_net_params.pkl')
